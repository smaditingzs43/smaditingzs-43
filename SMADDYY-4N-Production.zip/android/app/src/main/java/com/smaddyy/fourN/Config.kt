package com.smaddyy.fourN

import android.net.Uri

object Config {
    /** Injected at build time from -PBACKEND_URL (see app/build.gradle.kts). */
    const val BACKEND_URL: String = BuildConfig.BACKEND_URL

    val trustedHost: String? get() = Uri.parse(BACKEND_URL).host
}
