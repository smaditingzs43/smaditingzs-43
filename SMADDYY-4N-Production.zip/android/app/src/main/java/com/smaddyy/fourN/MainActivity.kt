package com.smaddyy.fourN

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingWebPermission: PermissionRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = FrameLayout(this).apply { setBackgroundColor(0xFF0B1020.toInt()) }
        webView = WebView(this)
        container.addView(webView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(container)

        // Android 15 enforces edge-to-edge: keep the page clear of the status bar, nav bar and keyboard.
        container.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            }
            if (Build.VERSION.SDK_INT >= 30) WindowInsets.CONSUMED
            else @Suppress("DEPRECATION") ins.consumeSystemWindowInsets()
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webView.setBackgroundColor(0xFF0B1020.toInt())
        webView.webViewClient = AppWebViewClient()
        webView.webChromeClient = AppChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(Config.BACKEND_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    private fun isTrusted(uri: Uri): Boolean = uri.host != null && uri.host == Config.trustedHost

    // ---- Navigation: the JS bridge must only ever be reachable from our own backend origin ----
    private inner class AppWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            if (isTrusted(uri) && uri.scheme == Uri.parse(Config.BACKEND_URL).scheme) return false
            // Everything else (other sites, tel:, sms:, mailto:, wa.me ...) opens in the proper external app
            val scheme = uri.scheme ?: ""
            if (scheme in setOf("http", "https", "tel", "sms", "smsto", "mailto", "geo")) {
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                catch (_: Exception) { toast("No compatible app found") }
            }
            return true
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val html = """
                <html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
                <body style="margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;background:#0b1020;color:#e8ecff;font-family:sans-serif;text-align:center;padding:24px">
                <div><h2>Can't reach SMADDYY 4N</h2><p>Check your internet connection.</p>
                <p><a href="${Config.BACKEND_URL}" style="color:#6ea8ff;font-size:18px">Try again</a></p></div></body></html>"""
            view.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) { /* hook for future loading UI */ }
    }

    // ---- Mic / camera for the web app, file chooser for "Analyze file" and camera capture ----
    private inner class AppChromeClient : WebChromeClient() {
        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                if (!isTrusted(request.origin)) { request.deny(); return@runOnUiThread }
                val needed = mutableListOf<String>()
                request.resources.forEach {
                    when (it) {
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> needed += Manifest.permission.RECORD_AUDIO
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> needed += Manifest.permission.CAMERA
                    }
                }
                val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) request.grant(request.resources)
                else { pendingWebPermission = request; requestPermissions(missing.toTypedArray(), REQ_WEB_PERMS) }
            }
        }

        override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = cb
            return try {
                startActivityForResult(params.createIntent(), REQ_FILE); true
            } catch (_: Exception) {
                fileCallback = null; toast("No file picker available"); false
            }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != REQ_WEB_PERMS) return
        val req = pendingWebPermission ?: return
        pendingWebPermission = null
        if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) req.grant(req.resources) else req.deny()
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE -> {
                fileCallback?.onReceiveValue(
                    if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                )
                fileCallback = null
            }
            REQ_VOICE -> {
                val text = if (resultCode == RESULT_OK)
                    data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
                // JSONObject.quote produces a safely escaped JS string literal
                val js = "window.onNativeSpeech && window.onNativeSpeech(${JSONObject.quote(text ?: "")})"
                webView.evaluateJavascript(js, null)
            }
        }
    }

    // ---- Native actions. Every action opens a system screen; the user confirms the final step. ----
    inner class AndroidBridge {
        @JavascriptInterface fun isAndroidApp(): Boolean = true

        @JavascriptInterface fun openDialer() = runOnUiThread {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
        }

        @JavascriptInterface fun composeSms(number: String, body: String) = runOnUiThread {
            val clean = number.trim()
            if (!Regex("^[+0-9 ()-]{3,20}$").matches(clean)) { toast("Invalid phone number"); return@runOnUiThread }
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(clean)}"))
                .putExtra("sms_body", body.take(1000))
            launch(intent)
        }

        @JavascriptInterface fun shareText(text: String) = runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text.take(20000)) }
            startActivity(Intent.createChooser(intent, "Share with"))
        }

        @JavascriptInterface fun openUrl(url: String) = runOnUiThread {
            if (url.startsWith("https://") || url.startsWith("http://")) launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }

        @JavascriptInterface fun startVoice() = runOnUiThread {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to SMADDYY 4N")
            }
            try { startActivityForResult(intent, REQ_VOICE) } catch (_: Exception) { toast("Voice input isn't available on this device") }
        }

        @JavascriptInterface fun openApp(app: String) = runOnUiThread {
            val intent = when (app.lowercase()) {
                "camera" -> Intent("android.media.action.IMAGE_CAPTURE")
                "maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
                "settings" -> Intent(android.provider.Settings.ACTION_SETTINGS)
                "browser" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                "phone" -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                "youtube" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                else -> null
            }
            if (intent == null) toast("Shortcut not supported") else launch(intent)
        }
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { toast("No compatible app found") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object {
        private const val REQ_FILE = 1001
        private const val REQ_VOICE = 1002
        private const val REQ_WEB_PERMS = 1003
    }
}
