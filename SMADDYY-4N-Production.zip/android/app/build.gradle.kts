plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Backend URL is injected at build time:  -PBACKEND_URL=https://your-app.onrender.com/
// (the GitHub Actions workflow passes it from the BACKEND_URL repository variable)
val backendUrl: String = (project.findProperty("BACKEND_URL") as String?)
    ?: System.getenv("BACKEND_URL")
    ?: "http://10.0.2.2:3000/"

android {
    namespace = "com.smaddyy.fourN"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smaddyy.fourN"
        minSdk = 26
        targetSdk = 35
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = "1.0.0"
        buildConfigField("String", "BACKEND_URL", "\"$backendUrl\"")
    }

    buildFeatures { buildConfig = true }

    signingConfigs {
        // Real release signing when a keystore is supplied (see README); otherwise falls back to debug signing
        // so the APK is still installable for personal use.
        val ks = System.getenv("KEYSTORE_PATH")
        if (ks != null && file(ks).exists()) {
            create("release") {
                storeFile = file(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
