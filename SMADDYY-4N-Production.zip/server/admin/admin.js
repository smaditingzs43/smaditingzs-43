// Admin portal: authenticated, remote code editor for this project.
// Storage modes:
//   github - reads/writes the repo through the GitHub API (durable; each save is a commit that redeploys the site)
//   local  - reads/writes files on this server's disk (lost on redeploy on most hosts; limited to web/ by default)
import express from "express";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import * as L from "./admin-lib.js";

const COOKIE = "s4n_admin";
const SESSION_MS = 8 * 60 * 60 * 1000;

export function mountAdmin(app, { rootDir, adminDir }) {
  const password = process.env.ADMIN_PASSWORD || "";
  if (password.length < 12) {
    console.warn("Admin portal DISABLED: set ADMIN_PASSWORD to a unique passphrase of 12+ characters to enable /admin.");
    app.all(["/admin", "/admin/*"], (_req, res) => res.status(404).send("Not found"));
    return;
  }

  const secret = process.env.ADMIN_SESSION_SECRET ||
    crypto.createHash("sha256").update("s4n-admin-session:" + password).digest("hex");
  const ghToken = process.env.GITHUB_TOKEN || "";
  const ghRepo = /^[\w.-]+\/[\w.-]+$/.test(process.env.GITHUB_REPO || "") ? process.env.GITHUB_REPO : "";
  const ghBranch = /^[\w./-]+$/.test(process.env.GITHUB_BRANCH || "") ? process.env.GITHUB_BRANCH : "main";
  const mode = ghToken && ghRepo ? "github" : "local";
  const allowServerLocal = process.env.ALLOW_LIVE_SERVER_EDIT === "true";
  const opts = { mode, allowServerLocal };
  console.log(`Admin portal enabled at /admin (storage: ${mode}${mode === "github" ? ` ${ghRepo}@${ghBranch}` : ""})`);

  const r = express.Router();

  r.use((_req, res, next) => {
    res.set({
      "Cache-Control": "no-store",
      "X-Robots-Tag": "noindex, nofollow",
      "Content-Security-Policy": [
        "default-src 'self'",
        "script-src 'self' https://cdn.jsdelivr.net",
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
        "font-src 'self' https://cdn.jsdelivr.net data:",
        "worker-src blob: data:",
        "connect-src 'self'",
        "img-src 'self' data:",
        "frame-ancestors 'none'",
        "base-uri 'none'", "form-action 'self'"
      ].join("; ")
    });
    next();
  });

  // ---- static portal files ----
  r.get("/", (_req, res) => res.sendFile("admin.html", { root: adminDir }));
  r.get("/client.js", (_req, res) => res.type("js").sendFile("client.js", { root: adminDir }));

  const json = express.json({ limit: "2mb" });

  // ---- auth ----
  const loginLimiter = rateLimit({
    windowMs: 15 * 60_000, limit: 5, skipSuccessfulRequests: true,
    standardHeaders: true, legacyHeaders: false,
    message: { error: "Too many failed attempts. Try again in 15 minutes." }
  });

  r.post("/api/login", loginLimiter, json, (req, res) => {
    const pw = typeof req.body?.password === "string" ? req.body.password : "";
    if (!L.passwordMatches(pw, password)) {
      console.warn(`[admin] failed login from ${req.ip}`);
      return res.status(401).json({ error: "Wrong password." });
    }
    const csrf = crypto.randomBytes(24).toString("hex");
    const token = L.signSession({ exp: Date.now() + SESSION_MS, csrf }, secret);
    res.cookie(COOKIE, token, { httpOnly: true, secure: req.secure, sameSite: "strict", path: "/admin", maxAge: SESSION_MS });
    console.log(`[admin] login from ${req.ip}`);
    res.json({ ok: true });
  });

  function requireAuth(req, res, next) {
    const session = L.verifySession(L.parseCookies(req.headers.cookie)[COOKIE], secret);
    if (!session) return res.status(401).json({ error: "Please sign in." });
    if (req.method !== "GET" && !L.safeEqual(req.get("x-admin-csrf") || "", session.csrf)) {
      return res.status(403).json({ error: "Bad CSRF token. Reload the page." });
    }
    req.admin = session;
    next();
  }
  const audit = (req, action, p = "") => console.log(`[admin] ${req.ip} ${action} ${p}`.trim());
  const wrap = (fn) => (req, res) => fn(req, res).catch((e) => {
    console.error("[admin] error:", e?.message || e);
    res.status(e.status || 500).json({ error: e.publicMessage || "Server error." });
  });
  const fail = (status, publicMessage) => Object.assign(new Error(publicMessage), { status, publicMessage });

  r.post("/api/logout", requireAuth, (req, res) => {
    res.clearCookie(COOKIE, { path: "/admin" });
    res.json({ ok: true });
  });

  r.get("/api/session", requireAuth, (req, res) => res.json({
    ok: true, csrf: req.admin.csrf, mode, repo: mode === "github" ? `${ghRepo}@${ghBranch}` : null,
    canBuild: mode === "github", canRestart: mode === "local" && allowServerLocal
  }));

  // ---- GitHub storage ----
  async function gh(method, apiPath, body) {
    const resp = await fetch(`https://api.github.com/repos/${ghRepo}${apiPath}`, {
      method,
      headers: {
        Authorization: `Bearer ${ghToken}`, Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "smaddyy-4n-admin", "Content-Type": "application/json"
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(20_000)
    });
    const data = resp.status === 204 ? {} : await resp.json().catch(() => ({}));
    return { status: resp.status, data };
  }
  const ghPath = (p) => p.split("/").map(encodeURIComponent).join("/");
  const ghError = (status, data) => {
    if (status === 401 || status === 403) return fail(502, "GitHub rejected the token. It needs Contents and Actions read/write on this repo.");
    if (status === 404) return fail(404, "Not found on GitHub (check GITHUB_REPO / GITHUB_BRANCH).");
    if (status === 409 || status === 422) return fail(409, "This file changed since you opened it, or already exists. Reload it and re-apply your edit.");
    return fail(502, `GitHub error (${status}).`);
  };

  // ---- local storage ----
  const abs = async (p) => {
    const full = path.resolve(rootDir, p);
    if (!full.startsWith(path.resolve(rootDir) + path.sep)) throw fail(400, "Invalid path.");
    return full;
  };
  async function walk(dir, rel, out) {
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const relPath = rel ? `${rel}/${e.name}` : e.name;
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) await walk(path.join(dir, e.name), relPath, out);
      else if (L.isEditablePath(relPath, opts)) out.push(relPath);
    }
  }

  // ---- file API ----
  r.get("/api/files", requireAuth, wrap(async (_req, res) => {
    let files = [];
    if (mode === "github") {
      const { status, data } = await gh("GET", `/git/trees/${encodeURIComponent(ghBranch)}?recursive=1`);
      if (status !== 200) throw ghError(status, data);
      files = (data.tree || []).filter((t) => t.type === "blob" && L.isEditablePath(t.path, opts)).map((t) => t.path);
    } else {
      await walk(path.join(rootDir, "web"), "web", files);
      if (allowServerLocal) await walk(path.join(rootDir, "server"), "server", files);
    }
    res.json({ files: files.sort() });
  }));

  r.get("/api/file", requireAuth, wrap(async (req, res) => {
    const p = String(req.query.path || "");
    if (!L.isEditablePath(p, opts)) throw fail(400, "That file can't be edited here.");
    if (mode === "github") {
      const { status, data } = await gh("GET", `/contents/${ghPath(p)}?ref=${encodeURIComponent(ghBranch)}`);
      if (status !== 200) throw ghError(status, data);
      if (data.encoding !== "base64" || typeof data.content !== "string") throw fail(413, "File is too large to edit here.");
      return res.json({ path: p, content: Buffer.from(data.content, "base64").toString("utf8"), version: data.sha });
    }
    const full = await abs(p);
    const st = await fs.lstat(full).catch(() => null);
    if (!st || !st.isFile()) throw fail(404, "File not found.");
    if (st.size > L.MAX_FILE_BYTES) throw fail(413, "File is too large to edit here.");
    const content = await fs.readFile(full, "utf8");
    res.json({ path: p, content, version: L.contentVersion(content) });
  }));

  r.put("/api/file", requireAuth, json, wrap(async (req, res) => {
    const { path: p, content, version } = req.body || {};
    if (!L.isEditablePath(p, opts)) throw fail(400, "That file can't be edited here.");
    const check = L.validateContent(p, content);
    if (!check.ok) throw fail(400, check.error);
    audit(req, "save", p);

    if (mode === "github") {
      const body = {
        message: `Admin portal: update ${p}`, branch: ghBranch,
        content: Buffer.from(content, "utf8").toString("base64"),
        ...(version ? { sha: version } : {})
      };
      const { status, data } = await gh("PUT", `/contents/${ghPath(p)}`, body);
      if (status !== 200 && status !== 201) throw ghError(status, data);
      return res.json({ ok: true, version: data.content?.sha, note: "Committed to GitHub. The host will redeploy automatically." });
    }

    const full = await abs(p);
    const st = await fs.lstat(full).catch(() => null);
    if (st?.isSymbolicLink()) throw fail(400, "Invalid path.");
    if (st) {
      const current = await fs.readFile(full, "utf8");
      if (version !== L.contentVersion(current)) throw fail(409, "This file changed since you opened it. Reload it and re-apply your edit.");
      const bdir = path.join(rootDir, "server", ".admin-backups");
      await fs.mkdir(bdir, { recursive: true });
      await fs.writeFile(path.join(bdir, `${Date.now()}-${p.replaceAll("/", "_")}`), current);
    } else if (version) throw fail(409, "File no longer exists.");
    await fs.mkdir(path.dirname(full), { recursive: true });
    const tmp = `${full}.tmp-${process.pid}`;
    await fs.writeFile(tmp, content);
    await fs.rename(tmp, full);
    res.json({
      ok: true, version: L.contentVersion(content),
      note: p.startsWith("web/") ? "Saved. Reload the app to see it (installed apps may need a second reload)."
        : "Saved. Restart the server for server-code changes to take effect. A redeploy will discard this edit."
    });
  }));

  r.post("/api/build", requireAuth, wrap(async (req, res) => {
    if (mode !== "github") throw fail(400, "Building the APK needs GitHub mode.");
    audit(req, "build-apk");
    const { status, data } = await gh("POST", "/actions/workflows/build-apk.yml/dispatches", { ref: ghBranch });
    if (status !== 204) throw ghError(status, data);
    res.json({ ok: true, note: "APK build started. Download it from the repo's Actions tab in a few minutes." });
  }));

  r.post("/api/restart", requireAuth, (req, res) => {
    if (!(mode === "local" && allowServerLocal)) return res.status(400).json({ error: "Restart is not enabled." });
    audit(req, "restart");
    res.json({ ok: true, note: "Restarting… the host should bring the server back in a few seconds." });
    setTimeout(() => process.exit(0), 500);
  });

  app.use("/admin", r);
}
