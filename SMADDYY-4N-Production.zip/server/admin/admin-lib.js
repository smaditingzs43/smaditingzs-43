// Pure helpers for the admin portal (no Express dependency, unit-tested in admin-lib.test.mjs).
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

export const MAX_FILE_BYTES = 1_000_000;

const TEXT_EXT = new Set([".js", ".mjs", ".json", ".html", ".css", ".md", ".txt", ".kt", ".kts", ".xml", ".yml", ".yaml", ".properties", ".webmanifest", ".pro"]);
const EXACT_NAMES = new Set(["Dockerfile", ".gitignore", ".env.example"]);
const ALLOW_PREFIXES = ["web/", "server/", "android/app/src/"];
const ALLOW_EXACT = new Set([
  "android/app/build.gradle.kts", "android/build.gradle.kts", "android/settings.gradle.kts",
  "android/gradle.properties", "README.md", "Dockerfile", "render.yaml", ".gitignore"
]);
const DENY_DIRS = new Set(["node_modules", ".git", ".gradle", "build", ".admin-backups"]);
// The portal never edits itself: a typo there could lock you out.
const PROTECTED_PREFIX = "server/admin/";

/** Returns the path if it is a safe, normalized, repo-relative POSIX path; otherwise null. */
export function normalizePath(p) {
  if (typeof p !== "string" || !p || p.length > 300) return null;
  if (p.includes("\0") || p.includes("\\") || p.startsWith("/")) return null;
  if (path.posix.normalize(p) !== p) return null;
  if (p.split("/").some((s) => s === "" || s === "." || s === "..")) return null;
  return p;
}

/** mode: "github" (whole project) or "local" (files on this server's disk). */
export function isEditablePath(p, { mode = "github", allowServerLocal = false } = {}) {
  const n = normalizePath(p);
  if (!n) return false;
  const parts = n.split("/");
  const base = parts[parts.length - 1];
  if (parts.slice(0, -1).some((d) => DENY_DIRS.has(d))) return false;
  if (n.startsWith(PROTECTED_PREFIX)) return false;
  if (base.startsWith(".env") && base !== ".env.example") return false;
  const ext = path.posix.extname(base).toLowerCase();
  if (!TEXT_EXT.has(ext) && !EXACT_NAMES.has(base)) return false;
  if (base === "package-lock.json") return false;
  if (mode === "local") {
    if (n.startsWith("web/")) return true;
    return allowServerLocal && n.startsWith("server/");
  }
  return ALLOW_EXACT.has(n) || ALLOW_PREFIXES.some((pre) => n.startsWith(pre));
}

// ---- sessions: signed, expiring, with a per-session CSRF token ----
export function signSession(payload, secret) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const mac = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${mac}`;
}

export function verifySession(token, secret, now = Date.now()) {
  if (typeof token !== "string") return null;
  const i = token.indexOf(".");
  if (i < 1) return null;
  const body = token.slice(0, i);
  const mac = Buffer.from(token.slice(i + 1));
  const expected = Buffer.from(crypto.createHmac("sha256", secret).update(body).digest("base64url"));
  if (mac.length !== expected.length || !crypto.timingSafeEqual(mac, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (typeof payload.exp !== "number" || payload.exp <= now) return null;
    return payload;
  } catch { return null; }
}

const sha256 = (s) => crypto.createHash("sha256").update(String(s)).digest();
/** Constant-time password check (hashing first removes length leakage). */
export function passwordMatches(input, expected) {
  return crypto.timingSafeEqual(sha256(input), sha256(expected));
}

export function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  return crypto.timingSafeEqual(sha256(a), sha256(b));
}

export function parseCookies(header = "") {
  const out = {};
  for (const part of String(header).split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/** Refuse obviously broken saves so a typo can't take the live site down. */
export function validateContent(filePath, content) {
  if (typeof content !== "string") return { ok: false, error: "Content must be text." };
  if (Buffer.byteLength(content, "utf8") > MAX_FILE_BYTES) return { ok: false, error: "File is larger than 1 MB." };
  if (content.includes("\0")) return { ok: false, error: "Binary content is not allowed." };
  const ext = path.posix.extname(filePath).toLowerCase();
  if (ext === ".json" || ext === ".webmanifest") {
    try { JSON.parse(content); } catch (e) { return { ok: false, error: `Invalid JSON: ${e.message}` }; }
  }
  if (ext === ".js" || ext === ".mjs") {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "s4n-check-"));
    // server code is ES modules; browser scripts are classic scripts
    const file = path.join(dir, filePath.startsWith("server/") ? "check.mjs" : "check.js");
    try {
      fs.writeFileSync(file, content);
      const r = spawnSync(process.execPath, ["--check", file], { encoding: "utf8", timeout: 5000 });
      if (r.status !== 0) {
        const msg = (r.stderr || "Syntax error").split("\n").filter(Boolean).slice(0, 5).join("\n").replaceAll(dir, "");
        return { ok: false, error: `JavaScript syntax error:\n${msg}` };
      }
    } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  }
  return { ok: true };
}

export const contentVersion = (text) => crypto.createHash("sha1").update(text).digest("hex");
