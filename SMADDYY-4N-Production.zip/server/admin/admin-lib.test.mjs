import test from "node:test";
import assert from "node:assert/strict";
import * as L from "./admin-lib.js";

test("normalizePath rejects traversal and odd input", () => {
  for (const bad of ["../server/.env", "web/../.env", "/etc/passwd", "web\\app.js", "web//app.js", "web/./app.js", "", "a\0b", "web/", null, 5]) {
    assert.equal(L.normalizePath(bad), null, String(bad));
  }
  assert.equal(L.normalizePath("web/app.js"), "web/app.js");
});

test("editable allowlist (github mode)", () => {
  const ok = ["web/app.js", "web/index.html", "server/server.js", "server/.env.example", "android/app/src/main/java/com/smaddyy/fourN/MainActivity.kt", "android/app/build.gradle.kts", "README.md", "Dockerfile"];
  const no = ["server/.env", "server/.env.production", "server/node_modules/x/index.js", ".git/config", ".github/workflows/build-apk.yml",
    "server/admin/admin.js", "web/icon-192.png", "android/app/release.jks", "server/package-lock.json", "android/app/build/outputs/x.xml", "random/file.js"];
  ok.forEach((p) => assert.ok(L.isEditablePath(p, { mode: "github" }), p));
  no.forEach((p) => assert.ok(!L.isEditablePath(p, { mode: "github" }), p));
});

test("local mode: web only unless server editing is enabled", () => {
  assert.ok(L.isEditablePath("web/app.js", { mode: "local" }));
  assert.ok(!L.isEditablePath("server/server.js", { mode: "local" }));
  assert.ok(L.isEditablePath("server/server.js", { mode: "local", allowServerLocal: true }));
  assert.ok(!L.isEditablePath("android/app/build.gradle.kts", { mode: "local", allowServerLocal: true }));
  assert.ok(!L.isEditablePath("server/admin/admin-lib.js", { mode: "local", allowServerLocal: true }));
});

test("sessions: valid, tampered, expired, wrong secret", () => {
  const t = L.signSession({ exp: Date.now() + 1000, csrf: "x" }, "secret");
  assert.equal(L.verifySession(t, "secret").csrf, "x");
  assert.equal(L.verifySession(t, "other"), null);
  assert.equal(L.verifySession(t.slice(0, -2) + "xx", "secret"), null);
  const [b, m] = t.split(".");
  const forged = Buffer.from(JSON.stringify({ exp: Date.now() + 9e9, csrf: "x" })).toString("base64url");
  assert.equal(L.verifySession(`${forged}.${m}`, "secret"), null);
  assert.equal(L.verifySession(L.signSession({ exp: 1 }, "secret"), "secret"), null);
  assert.equal(L.verifySession(undefined, "secret"), null);
  assert.equal(L.verifySession("nodot", "secret"), null);
});

test("password and csrf comparison", () => {
  assert.ok(L.passwordMatches("correct horse battery", "correct horse battery"));
  assert.ok(!L.passwordMatches("correct horse batterx", "correct horse battery"));
  assert.ok(!L.passwordMatches("", "correct horse battery"));
  assert.ok(L.safeEqual("a", "a") && !L.safeEqual("a", "b") && !L.safeEqual(undefined, "b"));
});

test("cookie parsing", () => {
  assert.deepEqual(L.parseCookies("a=1; s4n_admin=abc.def; z=%20q"), { a: "1", s4n_admin: "abc.def", z: " q" });
});

test("validateContent catches broken code before it is saved", () => {
  assert.ok(L.validateContent("web/app.js", "const a = 1;\nconsole.log(a);").ok);
  assert.ok(!L.validateContent("web/app.js", "const a = ;").ok);
  assert.ok(L.validateContent("server/server.js", "import fs from 'node:fs';\nexport const x = 1;").ok);
  assert.ok(!L.validateContent("server/server.js", "import fs from 'node:fs'\nfunction (").ok);
  assert.ok(L.validateContent("web/manifest.webmanifest", '{"a":1}').ok);
  assert.ok(!L.validateContent("web/manifest.webmanifest", "{a:1}").ok);
  assert.ok(!L.validateContent("web/x.html", "a\0b").ok);
  assert.ok(!L.validateContent("web/x.html", "a".repeat(1_000_001)).ok);
  assert.ok(L.validateContent("web/index.html", "<p>hi</p>").ok);
});
