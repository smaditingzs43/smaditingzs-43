(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const MONACO = "https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min";
  const LANGS = { js: "javascript", mjs: "javascript", json: "json", webmanifest: "json", html: "html", css: "css", md: "markdown",
    kt: "kotlin", kts: "kotlin", xml: "xml", yml: "yaml", yaml: "yaml", properties: "ini", txt: "plaintext" };

  let csrf = "", session = null, ed = null;
  const state = { path: null, version: null, original: "", dirty: false };

  // ---------- helpers ----------
  function setStatus(msg, kind = "") { const s = $("status"); s.textContent = msg; s.className = kind; }
  function langFor(p) { const base = p.split("/").pop(); if (base === "Dockerfile") return "dockerfile"; return LANGS[base.split(".").pop()] || "plaintext"; }
  async function api(method, url, body) {
    const res = await fetch("/admin/api" + url, {
      method, credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(csrf ? { "X-Admin-CSRF": csrf } : {}) },
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && url !== "/login") { showLogin(); throw new Error("Session expired. Please sign in again."); }
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  // ---------- editor (Monaco with textarea fallback) ----------
  function loadMonaco() {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout")), 15000);
      const s = document.createElement("script");
      s.src = MONACO + "/vs/loader.js";
      s.onerror = () => reject(new Error("load failed"));
      s.onload = () => {
        window.MonacoEnvironment = {
          getWorkerUrl: () => "data:text/javascript;charset=utf-8," + encodeURIComponent(
            `self.MonacoEnvironment={baseUrl:"${MONACO}/"};importScripts("${MONACO}/vs/base/worker/workerMain.js");`)
        };
        window.require.config({ paths: { vs: MONACO + "/vs" } });
        window.require(["vs/editor/editor.main"], () => { clearTimeout(timer); resolve(window.monaco); }, reject);
      };
      document.head.appendChild(s);
    });
  }

  function textareaEditor(host) {
    const ta = document.createElement("textarea");
    ta.id = "fallback"; ta.spellcheck = false;
    host.replaceChildren(ta);
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Tab") { e.preventDefault(); const { selectionStart: a, selectionEnd: b } = ta; ta.setRangeText("  ", a, b, "end"); ta.dispatchEvent(new Event("input")); }
    });
    return { get: () => ta.value, set: (t) => { ta.value = t; }, onChange: (cb) => ta.addEventListener("input", cb), layout() {} };
  }

  async function initEditor() {
    const host = $("editor");
    try {
      const monaco = await loadMonaco();
      const editor = monaco.editor.create(host, { value: "", language: "plaintext", theme: "vs-dark", automaticLayout: true,
        minimap: { enabled: false }, fontSize: 14, tabSize: 2, scrollBeyondLastLine: false, wordWrap: "off" });
      editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, save);
      return {
        get: () => editor.getValue(),
        set: (t, lang) => { const m = monaco.editor.createModel(t, lang); const old = editor.getModel(); editor.setModel(m); old && old.dispose(); },
        onChange: (cb) => editor.onDidChangeModelContent(cb)
      };
    } catch {
      setStatus("Code editor couldn't load from the CDN; using the basic editor.", "err");
      return textareaEditor(host);
    }
  }

  // ---------- file tree ----------
  function buildTree(files) {
    const root = {};
    for (const f of files) { let n = root; const parts = f.split("/"); parts.slice(0, -1).forEach((d) => { n = n[d] ??= {}; }); n[parts.at(-1)] = f; }
    const render = (node, open) => {
      const frag = document.createDocumentFragment();
      const keys = Object.keys(node).sort((a, b) => (typeof node[a] === "string") - (typeof node[b] === "string") || a.localeCompare(b));
      for (const k of keys) {
        if (typeof node[k] === "string") {
          const b = document.createElement("button");
          b.className = "file"; b.textContent = k; b.dataset.path = node[k]; b.addEventListener("click", () => openFile(node[k]));
          frag.appendChild(b);
        } else {
          const d = document.createElement("details"); d.open = open;
          const s = document.createElement("summary"); s.textContent = k + "/";
          d.append(s, render(node[k], false)); frag.appendChild(d);
        }
      }
      return frag;
    };
    $("tree").replaceChildren(render(root, true));
    $("tree").querySelectorAll("details details").forEach((d) => { d.open = d.querySelector(".file.active") !== null; });
  }
  function markActive() {
    document.querySelectorAll("#tree .file").forEach((b) => {
      b.classList.toggle("active", b.dataset.path === state.path);
      b.classList.toggle("dirty", b.dataset.path === state.path && state.dirty);
    });
  }
  async function refreshTree() { const { files } = await api("GET", "/files"); buildTree(files); markActive(); }

  // ---------- file actions ----------
  function setDirty(v) { state.dirty = v; $("filename").textContent = (state.path || "No file open") + (v ? "  ● unsaved" : ""); markActive(); }
  function load(path, content, version, dirty = false) {
    state.path = path; state.version = version; state.original = dirty ? state.original : content;
    ed.set(content, langFor(path)); setDirty(dirty);
  }
  async function openFile(path) {
    if (state.dirty && !confirm("Discard unsaved changes?")) return;
    try {
      setStatus("Loading " + path + "…");
      const f = await api("GET", "/file?path=" + encodeURIComponent(path));
      load(f.path, f.content, f.version); setStatus("Opened " + path);
    } catch (e) { setStatus(e.message, "err"); }
  }
  async function save() {
    if (!state.path) return setStatus("Open a file first.", "err");
    $("saveBtn").disabled = true; setStatus("Checking and saving…");
    try {
      const content = ed.get();
      const r = await api("PUT", "/file", { path: state.path, content, version: state.version });
      state.version = r.version; state.original = content; setDirty(false);
      setStatus(`Saved ${state.path}. ${r.note || ""}`, "ok");
      if (!document.querySelector(`#tree .file[data-path="${CSS.escape(state.path)}"]`)) refreshTree();
    } catch (e) { setStatus(e.message, "err"); }
    finally { $("saveBtn").disabled = false; }
  }

  async function startApp() {
    session = await api("GET", "/session"); csrf = session.csrf;
    $("login").classList.add("hidden"); $("app").classList.remove("hidden");
    $("modeBadge").textContent = session.mode === "github" ? "GitHub: " + session.repo : "Local files (not permanent)";
    $("buildBtn").classList.toggle("hidden", !session.canBuild);
    $("restartBtn").classList.toggle("hidden", !session.canRestart);
    if (!ed) { ed = await initEditor(); ed.onChange(() => { if (state.path) setDirty(ed.get() !== state.original); }); }
    await refreshTree();
    if (session.mode === "local") setStatus("Local mode: edits live on this server's disk and are lost on redeploy. Set GITHUB_TOKEN/GITHUB_REPO to make them permanent.");
  }
  function showLogin() { csrf = ""; $("app").classList.add("hidden"); $("login").classList.remove("hidden"); $("pw").value = ""; $("pw").focus(); }

  // ---------- wiring ----------
  $("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault(); $("err").textContent = "";
    try { await api("POST", "/login", { password: $("pw").value }); $("pw").value = ""; await startApp(); }
    catch (er) { $("err").textContent = er.message; }
  });
  $("saveBtn").addEventListener("click", save);
  $("revertBtn").addEventListener("click", () => { if (state.path && confirm("Revert to the last saved version?")) { ed.set(state.original, langFor(state.path)); setDirty(false); } });
  $("dlBtn").addEventListener("click", () => {
    if (!state.path) return;
    const a = document.createElement("a"); a.download = state.path.split("/").pop();
    a.href = URL.createObjectURL(new Blob([ed.get()], { type: "text/plain" })); a.click(); URL.revokeObjectURL(a.href);
  });
  $("openBtn").addEventListener("click", () => { if (!state.path) return setStatus("Open the file you want to replace first.", "err"); $("uploadInput").click(); });
  $("uploadInput").addEventListener("change", async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    if (f.size > 1_000_000) return setStatus("File is larger than 1 MB.", "err");
    const text = await f.text();
    ed.set(text, langFor(state.path)); setDirty(true);
    setStatus(`Loaded ${f.name} into ${state.path}. Review it, then press Save.`);
  });
  $("newBtn").addEventListener("click", () => {
    if (state.dirty && !confirm("Discard unsaved changes?")) return;
    const p = prompt("New file path (e.g. web/extra.css):"); if (!p) return;
    load(p.trim(), "", null, false); setDirty(true); setStatus("New file. Press Save to create it.");
  });
  $("buildBtn").addEventListener("click", async () => {
    if (!confirm("Start a new APK build on GitHub Actions?")) return;
    try { setStatus((await api("POST", "/build")).note, "ok"); } catch (e) { setStatus(e.message, "err"); }
  });
  $("restartBtn").addEventListener("click", async () => {
    if (!confirm("Restart the server now?")) return;
    try { setStatus((await api("POST", "/restart")).note, "ok"); } catch (e) { setStatus(e.message, "err"); }
  });
  $("logoutBtn").addEventListener("click", async () => { try { await api("POST", "/logout"); } catch {} showLogin(); });
  window.addEventListener("beforeunload", (e) => { if (state.dirty) { e.preventDefault(); e.returnValue = ""; } });
  window.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); save(); } });

  // already signed in (cookie still valid)?
  api("GET", "/session").then(startApp).catch(showLogin);
})();
