const $ = id => document.getElementById(id);
const messages=$("messages"), promptBox=$("prompt");
let deferredInstall=null;
function addBubble(text,who="assistant",extra=""){
 const el=document.createElement("div");el.className=`bubble ${who} ${extra}`.trim();el.textContent=text;
 messages.appendChild(el);messages.scrollTop=messages.scrollHeight;return el;
}
function saveHistory(){
 const history=[...messages.children].slice(-50).map(x=>({text:x.textContent,who:x.classList.contains("user")?"user":"assistant"}));
 try{localStorage.setItem("smaddyy4n-history",JSON.stringify(history));}catch{}
}
function restoreHistory(){
 try{const d=JSON.parse(localStorage.getItem("smaddyy4n-history")||"[]");if(d.length){messages.replaceChildren();d.forEach(x=>addBubble(x.text,x.who));}}catch{}
}
async function apiPost(url,body,form=false){
 const r=await fetch(url,{method:"POST",headers:form?{}:{"Content-Type":"application/json"},body:form?body:JSON.stringify(body)});
 const d=await r.json();if(!r.ok)throw new Error(d.error||"Request failed");return d;
}
async function sendMessage(text){
 text=(text??promptBox.value).trim();if(!text)return;promptBox.value="";addBubble(text,"user");saveHistory();
 const pending=addBubble("Thinking…");$("sendBtn").disabled=true;
 try{const d=await apiPost("/api/chat",{message:text});pending.textContent=d.reply;speak(d.reply);}
 catch(e){pending.textContent=e.message;pending.classList.add("error");}
 finally{$("sendBtn").disabled=false;saveHistory();}
}
$("sendBtn").addEventListener("click",()=>sendMessage());
promptBox.addEventListener("keydown",e=>{if(e.key==="Enter")sendMessage();});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
$("clearBtn").addEventListener("click",()=>{messages.replaceChildren();localStorage.removeItem("smaddyy4n-history");addBubble("Chat cleared. What would you like to do?");});
function speak(text){if(!("speechSynthesis"in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="en-US";speechSynthesis.speak(u);}
window.onNativeSpeech=t=>{if(t&&t.trim())sendMessage(t.trim());else addBubble("I couldn't hear that. Please try again.");};
$("micBtn").addEventListener("click",()=>{
 if(window.AndroidBridge&&AndroidBridge.startVoice){AndroidBridge.startVoice();return;}
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){addBubble("Voice recognition is not supported here. Try Chrome on Android.");return;}
 const rec=new SR();rec.lang="en-US";rec.interimResults=false;
 rec.onresult=e=>sendMessage(e.results[0][0].transcript);rec.onerror=()=>addBubble("I couldn't hear that. Please try again.");rec.start();
});
async function analyzeFile(file){
 if(!file)return;addBubble(`Analyzing ${file.name}…`);
 const fd=new FormData();fd.append("file",file);fd.append("prompt","Analyze this file. Summarize key points, explain difficult sections, and identify important dates or actions.");
 try{const d=await apiPost("/api/analyze",fd,true);addBubble(d.reply);speak(d.reply);}
 catch(e){addBubble(e.message,"assistant","error");}
}
$("fileBtn").addEventListener("click",()=>$("fileInput").click());
$("fileInput").addEventListener("change",e=>{analyzeFile(e.target.files[0]);e.target.value="";});
$("cameraBtn").addEventListener("click",()=>$("cameraInput").click());
$("cameraInput").addEventListener("change",e=>{analyzeFile(e.target.files[0]);e.target.value="";});
$("shareBtn").addEventListener("click",async()=>{
 const share={title:"SMADDYY 4N",text:"Try SMADDYY 4N, my AI phone assistant.",url:location.href};
 if(navigator.share){try{await navigator.share(share);}catch{}}else{try{await navigator.clipboard.writeText(location.href);addBubble("Website link copied.");}catch{addBubble(location.href);}}
});
$("dialBtn").addEventListener("click",()=>{if(window.AndroidBridge)AndroidBridge.openDialer();else location.href="tel:";});
$("smsBtn").addEventListener("click",()=>composeSms());
function composeSms(){
 const number=prompt("Recipient phone number (optional):")||"";
 const body=prompt("Message to prepare:")||"";
 if(!body)return;
 if(window.AndroidBridge)AndroidBridge.composeSms(number,body);
 else location.href=`sms:${encodeURIComponent(number)}?body=${encodeURIComponent(body)}`;
}
$("whatsAppBtn").addEventListener("click",()=>{
 const number=prompt("WhatsApp number with country code, digits only (optional):")||"";
 const body=prompt("Message to prepare:")||"";
 if(!body)return;
 const digits=number.replace(/\D/g,"");
 const url=digits?`https://wa.me/${digits}?text=${encodeURIComponent(body)}`:`https://wa.me/?text=${encodeURIComponent(body)}`;
 if(window.AndroidBridge)AndroidBridge.openUrl(url);else window.open(url,"_blank","noopener");
});
$("appsBtn").addEventListener("click",()=>{
 const choice=prompt("Enter app: camera, maps, settings, browser, phone, or YouTube");
 if(!choice)return;
 if(window.AndroidBridge)AndroidBridge.openApp(choice.toLowerCase());
 else {
  const urls={maps:"https://maps.google.com",browser:"https://www.google.com",youtube:"https://www.youtube.com"};
  if(urls[choice.toLowerCase()])window.open(urls[choice.toLowerCase()],"_blank","noopener");
  else addBubble("This app shortcut is available in the Android companion app.");
 }
});
$("searchBtn").addEventListener("click",async()=>{
 const query=prompt("What would you like to search on the internet?");if(!query)return;
 addBubble("Search: "+query,"user");const p=addBubble("Searching the web…");
 try{const d=await apiPost("/api/search",{query});p.textContent=d.reply;speak(d.reply);}catch(e){p.textContent=e.message;p.classList.add("error");}
 saveHistory();
});

// Local task/reminder manager
const TASK_KEY="smaddyy4n-tasks";
function readTasks(){try{return JSON.parse(localStorage.getItem(TASK_KEY)||"[]");}catch{return[];}}
function writeTasks(tasks){localStorage.setItem(TASK_KEY,JSON.stringify(tasks));renderTasks();}
function renderTasks(){
 const ul=$("taskList");ul.replaceChildren();
 readTasks().forEach(task=>{
  const li=document.createElement("li");if(task.done)li.classList.add("done");
  const check=document.createElement("input");check.type="checkbox";check.checked=task.done;check.addEventListener("change",()=>{const a=readTasks();const t=a.find(x=>x.id===task.id);if(t)t.done=check.checked;writeTasks(a);});
  const label=document.createElement("span");label.textContent=task.text+(task.when?" · "+new Date(task.when).toLocaleString():"");
  const del=document.createElement("button");del.textContent="Delete";del.addEventListener("click",()=>writeTasks(readTasks().filter(x=>x.id!==task.id)));
  li.append(check,label,del);ul.append(li);
 });
}
$("tasksBtn").addEventListener("click",()=>{$("taskPanel").hidden=!$("taskPanel").hidden;renderTasks();});
$("closeTasks").addEventListener("click",()=>$("taskPanel").hidden=true);
$("taskForm").addEventListener("submit",e=>{
 e.preventDefault();const text=$("taskText").value.trim(),when=$("taskWhen").value;if(!text)return;
 const tasks=readTasks();tasks.unshift({id:Date.now().toString(),text,when,done:false});writeTasks(tasks);$("taskText").value="";$("taskWhen").value="";
 if(when && "Notification"in window && Notification.permission==="granted"){
  const delay=new Date(when).getTime()-Date.now();
  if(delay>0 && delay<2147480000)setTimeout(()=>new Notification("SMADDYY 4N reminder",{body:text}),delay);
 }
});
if("Notification"in window && Notification.permission==="default"){
 // Ask only after the user opens task panel; never prompt on page load.
 $("tasksBtn").addEventListener("dblclick",()=>Notification.requestPermission());
}
if(window.AndroidBridge)$("installBtn").style.display="none";
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;});
$("installBtn").addEventListener("click",async()=>{
 if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;}
 else addBubble("In Chrome, open the menu and choose 'Install app' or 'Add to Home screen'.");
});
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
fetch("/api/health").then(r=>r.json()).then(d=>{$("status").textContent=d.aiConfigured?"AI ready":"API key needed";}).catch(()=>$("status").textContent="Offline");
restoreHistory();renderTasks();
