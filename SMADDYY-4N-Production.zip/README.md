# SMADDYY 4N — AI Phone Assistant

# 🚀 Quick start: get it on your phone (about 15 minutes)

You need a free GitHub account, a free Render account, and an OpenAI API key.

## Step 1 — Put the code on GitHub
Create a new **private** repository and upload the contents of this folder (the folder that contains `android/`, `server/`, `web/`).

## Step 2 — Deploy the server (Render)
1. In Render choose **New → Blueprint** and select your repo. It reads `render.yaml`.
2. Paste your `OPENAI_API_KEY` when asked, then deploy.
3. Copy your URL, e.g. `https://smaddyy-4n.onrender.com`. Open it on your phone: the web app works already, and Chrome's menu offers **Install app**.
   *(Free Render services sleep after inactivity, so the first load can take ~30 s. A paid plan removes that. `Dockerfile` is included for Fly.io/Railway/etc.)*

## Step 3 — Build the APK (GitHub Actions)
1. In your repo: **Settings → Secrets and variables → Actions → Variables → New variable**
   Name `BACKEND_URL`, value your Render URL **with a trailing slash**, e.g. `https://smaddyy-4n.onrender.com/`
2. Go to **Actions → Build Android APK → Run workflow**.
3. When it finishes, download **SMADDYY-4N-apk** from the run's Artifacts, unzip, and send `SMADDYY-4N.apk` to your phone.
4. Open it and allow "install unknown apps" for the app you opened it from.

## Optional — proper release signing (needed for Play Store, and for smooth updates)
```bash
keytool -genkeypair -v -keystore release.jks -alias smaddyy -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks     # paste output into the secret below
```
Add repository secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`smaddyy`), `KEY_PASSWORD`. **Back up release.jks safely; if you lose it you can't update the app.**
Without these the APK is debug-signed: fine for personal use, but not for the Play Store.

## ⚠️ Before sharing the URL publicly
The server has no login. Anyone who finds your URL can use your OpenAI credit (limited to 30 requests/min per IP). Set a monthly spend limit in the OpenAI dashboard, and consider adding authentication before sharing widely.

## 🛠 Admin portal: edit the code from your computer's browser
Open `https://YOUR-SITE/admin`. It is **off until you set `ADMIN_PASSWORD`** (12+ characters, unique) in your host's environment variables.

**Recommended setup (permanent edits):** also set `GITHUB_TOKEN` and `GITHUB_REPO` (`your-username/your-repo`).
Create the token at GitHub → Settings → Developer settings → Fine-grained tokens, limited to **this one repo**, with **Contents: read/write** and **Actions: read/write**.
Then the portal edits your real repo: every Save is a commit, Render redeploys automatically, and the **Build APK** button starts the APK workflow. You can edit `web/`, `server/` (except `server/admin/`), the Android sources under `android/app/src/`, the Gradle files, and the README.

**Without GitHub (local mode):** you can edit `web/` files on the live server. Edits are lost on the next redeploy. Set `ALLOW_LIVE_SERVER_EDIT=true` to also edit `server/` (needs a restart to apply).

**Using your own computer's editor:** the portal runs Monaco (VS Code's editor) in the browser. Use **Download** to open a file in VS Code, then **Open from computer…** to load your edited copy back in and Save. Or skip the portal: `git clone` your repo, edit in VS Code, `git push`. Render redeploys on every push.

**Safety built in:** rate-limited login (5 wrong tries per 15 min), signed 8-hour sessions, CSRF protection, `.env`/keys/secrets are never listable or editable, path traversal blocked, JavaScript and JSON are syntax-checked before saving (so a typo can't take the site down), and the portal can't edit its own code. Tests: `node --test server/admin/admin-lib.test.mjs`.

> ⚠️ Whoever signs in controls your server and your OpenAI key. Use a password you've never used elsewhere, keep the GitHub token scoped to one repo, and don't share the URL.

## What changed from the original starter
- Android: backend URL injected at build time; HTTPS-only in release (cleartext only in debug); mic/camera permissions; file picker; native voice input (WebView has no speech API); edge-to-edge insets for Android 15; JS bridge locked to your own domain; offline error page; app icon.
- Web: PWA icons added (manifest was not installable without them); PDF/DOCX now selectable in the file picker.
- Server: proxy-aware rate limiting, Node engine pin, Dockerfile, `render.yaml`.
- Not verified here: I could not compile the Android project or run the server against OpenAI in my sandbox (no network/SDK). If the first Actions build fails, send me the log.

---

An advanced starter project containing:
- Responsive installable web app (PWA)
- Node.js/Express AI backend using the OpenAI Responses API
- Android companion app (Kotlin + WebView JavaScript bridge)
- User-confirmed native actions: dial, compose SMS, share text, open URLs
- Browser voice input/output, camera capture, file upload and AI analysis
- Local chat history in the browser
- Basic server-side rate limiting and input validation

## Important capability boundary
A web page or ordinary Android app cannot silently control the whole phone. Android requires user consent and OS permissions. This project deliberately opens Android's native dialer/SMS composer and Android share sheet rather than secretly placing calls or sending messages. It does not read private SMS, call logs, WhatsApp messages, contacts, or change protected system settings. Accessibility-based control is not included.

## Requirements
- Node.js 20+
- OpenAI API key
- Android Studio (for APK build)
- HTTPS hosting for production web/PWA and browser camera/microphone features

## 1. Configure the backend
```bash
cd server
cp .env.example .env
# Edit .env and add OPENAI_API_KEY
npm install
npm start
```
Server defaults to http://localhost:3000.

## 2. Use the web app
Open http://localhost:3000 in a browser. For microphone/camera access, use localhost during development or HTTPS when deployed.

## 3. Build Android app
Open `android/` in Android Studio. Set the backend URL in:
`android/app/src/main/java/com/smaddyy/fourN/Config.kt`
- Emulator talking to a backend running on your computer: `http://10.0.2.2:3000`
- Physical phone on same Wi-Fi: `http://YOUR_COMPUTER_LAN_IP:3000`
- Production: use your HTTPS deployment URL.

For local HTTP development, the app enables cleartext traffic. Use HTTPS in production.
Build > Build Bundle(s) / APK(s) > Build APK(s).

## 4. API key security
Never put the OpenAI API key in the web app, Android app, or a public repository. Keep it only in `server/.env` or your hosting provider's secret manager.

## 5. Deploy
Deploy the `server/` directory to a Node.js host that supports persistent environment variables. Set:
- `OPENAI_API_KEY`
- `OPENAI_MODEL` (default `gpt-4.1-mini`)
- `PORT` (provided by host)
Then point the Android `Config.kt` to the HTTPS backend URL. The web app is served by the same backend.

## Included API routes
- `GET /api/health`
- `POST /api/chat` — text chat
- `POST /api/analyze` — image/PDF/DOCX/text document analysis
- `POST /api/search` — web search and AI summary
- `GET /api/config` — public feature configuration (no secrets)

## Advanced functions and limits
- SMS: Android opens the system SMS composer with the draft. The user reviews and presses Send.
- WhatsApp: opens the official `wa.me` link. The user reviews and sends in WhatsApp; WhatsApp must be installed or its web flow available.
- Phone commands: launch a small allowlist of Android activities. The app does not silently execute arbitrary commands.
- Tasks/reminders: stored locally in browser storage. Scheduled notifications are best-effort and may not fire if the browser is closed or the OS suspends it. For reliable reminders use native Android WorkManager/AlarmManager with user-visible notification permission.
- Camera: Android companion can launch the camera app; the PWA can capture/select an image and upload it for analysis.
- Accessibility: no AccessibilityService is enabled. Accessibility services can observe and interact with other apps and require explicit user opt-in and a clear accessibility use case. This assistant uses normal Android intents and accessibility-friendly UI instead.
- Documents: PDF and DOCX extraction is included; old binary .doc is not supported. Uploaded files are held in memory and limited to 12 MB. Add malware scanning, stricter MIME validation and retention policies before production.
- Internet search: uses the OpenAI Responses API web-search preview tool. Confirm that your chosen API account/model has access; if not, switch to an available supported web search tool/model.

- This is a runnable foundation, not a guarantee of unrestricted device automation.
